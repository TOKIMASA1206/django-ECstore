// document.addEventListener(
//   "visibilitychange",
//   () => {
//     if (document.visibilityState === "visible") {
//       window.location = "/pay/cancel/";
//     }
//   },
//   false
// );